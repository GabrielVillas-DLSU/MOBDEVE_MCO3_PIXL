package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Notifications_MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.notifications_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.notifspage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.notifications_recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        NotificationsData[] notifsData = new NotificationsData[]{
                new NotificationsData("UPCOMING RELEASE - TEKKEN 8", "Horizon Press", "The much-awaited TEKKEN 8 will be released on Pixl on January 25, 2024. New features, characters, events, and many more will be included in this game.", "December 30, 2023"),
                new NotificationsData("Weekend Deal - LocoRoco, 25% Off!", "Starlight Games", "Save 25% off on LOCOROCO as part of this week's WEEKEND DEAL! Offer ends on Monday, 12:01 AM.", "January 16, 2024"),
                new NotificationsData("Daily Deal - Block Blast, 50% Off!", "Zero Signal", "Today's Deal: Save 50% on BLOCK BLAST!* Wait for more deals on our page or follow us on our social media pages. Offer ends on February 12, 2024.", "February 11, 2024"),
                new NotificationsData("MySims is making a comeback!", "PixelParlor", "MySims is back! There will be a new bundle featuring MySims and MySims Kingdom. This will be launched on November 22, 2024.", "April 6, 2024"),
                new NotificationsData("LEGO Harry Potter Collection is now available!", "Starlight Games", "Remastered Versions of LEGO Harry Potter: Years 1-4 and Years 5-7 are now available in Pixl! Explore cast spells, duel, solve puzzles, and many more in the world of Harry Potter now!", "July 17, 2024"),
        };

        NotificationsAdapter notifsAdapter = new NotificationsAdapter(notifsData, Notifications_MainActivity.this);
        recyclerView.setAdapter(notifsAdapter);
    }
}