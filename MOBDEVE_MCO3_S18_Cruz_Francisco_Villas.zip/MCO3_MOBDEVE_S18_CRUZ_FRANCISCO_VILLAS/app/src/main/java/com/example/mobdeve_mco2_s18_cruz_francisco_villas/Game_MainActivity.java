package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Game_MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.game_publisher);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.gamepub), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.games_recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        GameData[] gameData = new GameData[]{
                new GameData(R.drawable.crashbandicoot, "Crash Bandicoot N. Sane Trilogy", 2400,
                        "Your favorite marsupial, Crash Bandicoot™, is back! He’s enhanced, entranced and ready-to-dance with the N. Sane Trilogy game collection. Now you can experience Crash Bandicoot like never before."),
                new GameData(R.drawable.smashmelee, "Super Smash Bros. Melee", 2900,
                        "Super Smash Bros. Melee[a] is a 2001 crossover fighting video game developed by HAL Laboratory and published by Nintendo for the GameCube. It is the second installment in the Super Smash Bros. series."),
                new GameData(R.drawable.locoroco, "LocoRoco", 995,
                        "The world is under attack from the dastardly Moja Corps, and only the cheerful tunes of the LocoRoco can stop them."),
        };

        GameAdapter gameAdapter = new GameAdapter(gameData, Game_MainActivity.this);
        recyclerView.setAdapter(gameAdapter);
    }
}
