package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class NewReleaseMainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.new_release_main_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        NewReleaseData[] newReleaseData = new NewReleaseData[]{
                new NewReleaseData("Hope of Taru","Free to Play",R.drawable.hope_of_taru,"Find the hints to your past and bring back life to your village in this small indie 2D platformer. Enjoy stunning artwork and an original soundtrack while unravelling the story of the mysterious village Taru in six increasingly challenging levels"),
                new NewReleaseData("Liars Bar","239 Pesos",R.drawable.liars_bars,  "Dive into this multiplayer online experience set in a sketchy bar where the games are as dangerous as the patrons. Join a table of 4 and test your skills in Liar's Dice and Liar's Deck, where lying and bluffing are key to victory. Ready for a night at Liar's Bar"),
                new NewReleaseData("DRAGON BALL: Sparking! ZERO","2,799 pesos",R.drawable.dragon_ball, "DRAGON BALL: Sparking! ZERO takes the legendary gameplay of the Budokai Tenkaichi series and raises it to whole new levels. Make yours the destructive power of the strongest fighters ever to appear in DRAGON BALL!"),
                new NewReleaseData("MechWarrior 5: Clans","1,400 pesos",R.drawable.mech_warrior_clans, "In MECHWARRIOR 5: CLANS, players become new Smoke Jaguar pilots in the Clan Invasion of the Inner Sphere. Lead a five-mech \"Star\" squad across diverse planets, engaging in an expansive campaign with immersive gameplay and intricate combat. Customize BattleMechs and explore strategic"),
                new NewReleaseData("A Quiet Place: The Road Ahead","895 Pesos",R.drawable.quiet_place, "A Quiet Place: The Road Ahead is a single-player horror adventure game inspired by the critically acclaimed blockbuster movie franchise. Survive in silence."),
                new NewReleaseData("Once Human","Free To Play",R.drawable.once_human, "Once Human is a multiplayer open-world survival game set in a strange, post-apocalyptic future. Unite with friends to fight monstrous enemies, uncover secret plots, compete for resources, and build your own territory. Once, you were merely human. Now, you have the power to remake the world."),
                new NewReleaseData("TCG Card Shop Simulator","424 pesos",R.drawable.tcg_card_shop, "Open your own local game store. Stock shelves with the latest booster packs, or crack them and collect the cards for yourself. Set your own prices, hire staff, host events, and expand your card shop."),
        };

        NewReleaseAdapter newReleaseAdapter = new NewReleaseAdapter(newReleaseData,NewReleaseMainActivity.this);
        recyclerView.setAdapter(newReleaseAdapter);
    }
}