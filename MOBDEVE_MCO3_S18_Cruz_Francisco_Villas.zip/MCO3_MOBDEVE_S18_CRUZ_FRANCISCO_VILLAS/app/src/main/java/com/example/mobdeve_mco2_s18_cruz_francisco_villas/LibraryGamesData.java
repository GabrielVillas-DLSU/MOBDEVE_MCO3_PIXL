package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

public class LibraryGamesData {

    private String movieName;
    private String movieDate;
    private Integer movieImage;
    private String movieSummary;

    public LibraryGamesData(String movieName, String movieDate, Integer movieImage, String movieSummary) {
        this.movieName = movieName;
        this.movieDate = movieDate;
        this.movieImage = movieImage;
        this.movieSummary = movieSummary;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieDate() {
        return movieDate;
    }

    public void setMovieDate(String movieDate) {
        this.movieDate = movieDate;
    }

    public Integer getMovieImage() {
        return movieImage;
    }

    public void setMovieImage(Integer movieImage) {
        this.movieImage = movieImage;
    }

    public String getMovieSummary() { return this.movieSummary; }

    public void setMovieSummary(String movieSummary){ this.movieSummary = movieSummary; }

}