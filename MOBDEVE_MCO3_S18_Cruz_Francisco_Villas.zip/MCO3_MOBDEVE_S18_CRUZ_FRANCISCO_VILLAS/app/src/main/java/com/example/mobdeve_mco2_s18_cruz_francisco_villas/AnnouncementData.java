package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

public class AnnouncementData {

    private String announcementTitle;
    private String announcementDesc;
    private String announcementDate;

    public AnnouncementData(String announcementTitle, String announcementDesc, String announcementDate) {
        this.announcementTitle = announcementTitle;
        this.announcementDesc = announcementDesc;
        this.announcementDate = announcementDate;
    }

    public String getAnnouncementTitle() {
        return announcementTitle;
    }

    public void setAnnouncementTitle(String announcementTitle) {
        this.announcementTitle = announcementTitle;
    }

    public String getAnnouncementDesc() {
        return announcementDesc;
    }

    public void setAnnouncementDesc(String announcementDesc) {
        this.announcementDesc = announcementDesc;
    }

    public String getAnnouncementDate() {
        return announcementDate;
    }

    public void setAnnouncementDate(String announcementDate) {
        this.announcementDate = announcementDate;
    }
}
