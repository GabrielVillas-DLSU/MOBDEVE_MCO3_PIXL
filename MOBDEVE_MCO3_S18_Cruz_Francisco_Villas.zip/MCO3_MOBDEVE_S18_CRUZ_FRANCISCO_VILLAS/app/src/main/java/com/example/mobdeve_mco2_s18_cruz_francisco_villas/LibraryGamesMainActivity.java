package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class LibraryGamesMainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.library_games_main_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        LibraryGamesData[] libraryGamesData= new LibraryGamesData[]{
                new LibraryGamesData("Resident Evil 4","Hours of Play: 48",R.drawable.residentevil4,"Achievements: Sprinter, OverKill, Promising Agent"),
                new LibraryGamesData("Stardew Valley","Hours of Play: 68",R.drawable.stardewvalley,  "Achievements: Cliques, Mother Catch, Blue Ribbon"),
                new LibraryGamesData("Tekken 8","Hours of Play: 88",R.drawable.tekken8, "Achievements: What a rush!, Behold, the fruit of our labors., Under the divine protection of Sirius"),
        };

        LibraryGamesAdapter libraryGamesAdapter = new LibraryGamesAdapter(libraryGamesData,LibraryGamesMainActivity.this);
        recyclerView.setAdapter(libraryGamesAdapter);
    }
}

