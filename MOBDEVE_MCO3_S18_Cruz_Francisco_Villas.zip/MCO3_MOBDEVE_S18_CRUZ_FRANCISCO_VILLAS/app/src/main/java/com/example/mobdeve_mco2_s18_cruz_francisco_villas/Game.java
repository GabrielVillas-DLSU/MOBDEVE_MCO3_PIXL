package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import java.io.Serializable;

public class Game implements Serializable {
    private String name;
    private double price;
    private int imageResource;

    public Game(String name, double price, int imageResource) {
        this.name = name;
        this.price = price;
        this.imageResource = imageResource;
    }

    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
    public int getImageResource() {
        return imageResource;
    }
}