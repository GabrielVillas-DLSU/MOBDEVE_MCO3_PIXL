package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.ViewHolder> {

    private List<Game> games;
    private OnRemoveClickListener removeClickListener;
    private Context context;

    public interface OnRemoveClickListener {
        void onRemoveClick(Game game);
    }

    public WishlistAdapter(Context context, List<Game> games, OnRemoveClickListener removeClickListener) {
        this.context = context;
        this.games = games;
        this.removeClickListener = removeClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_wishlist_game, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Game game = games.get(position);

        holder.gameName.setText(game.getName());
        holder.gamePrice.setText(String.format("₱%.2f", game.getPrice()));
        holder.gameImage.setImageResource(game.getImageResource());

        holder.addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (context instanceof WishlistActivity) {
                    ((WishlistActivity) context).addToCart(game);
                }
            }
        });

        holder.removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeClickListener.onRemoveClick(game);
            }
        });
    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView gameImage;
        TextView gameName;
        TextView gamePrice;
        Button addToCartButton;
        Button removeButton;

        ViewHolder(View itemView) {
            super(itemView);
            gameImage = itemView.findViewById(R.id.game_image);
            gameName = itemView.findViewById(R.id.game_name);
            gamePrice = itemView.findViewById(R.id.game_price);
            addToCartButton = itemView.findViewById(R.id.add_to_cart_button);
            removeButton = itemView.findViewById(R.id.remove_button);
        }
    }

    public void updateList(List<Game> newList) {
        games = newList;
        notifyDataSetChanged();
    }
}