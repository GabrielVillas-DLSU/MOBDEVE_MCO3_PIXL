package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomePage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.home_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.homepage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public void openFeaturedGames (View v){
        Intent i = new Intent(HomePage.this, FeaturedGames.class);
        startActivity(i);
    }
    public void openDiscountedGames (View v){
        Intent i = new Intent(HomePage.this, DiscountedMainActivity.class);
        startActivity(i);
    }
    public void openNewReleaseGames (View v){
        Intent i = new Intent(HomePage.this,NewReleaseMainActivity.class);
        startActivity(i);
    }
    public void viewCart (View v)
    {
        Intent i = new Intent(HomePage.this, CartActivity.class);
        startActivity(i);
    }

    public void viewWishlist (View v){
        Intent i = new Intent(HomePage.this, WishlistActivity.class);
        startActivity(i);
    }
    public void openNotification (View v){
        Intent i = new Intent(HomePage.this, Notifications_MainActivity.class);
        startActivity(i);
    }
    public void viewProfile (View v){
        Intent i = new Intent(HomePage.this, ProfileActivity.class);
        startActivity(i);
    }

    public void viewLibrary (View v){
        Intent i = new Intent(HomePage.this, LibraryGamesMainActivity.class);
        startActivity(i);
    }
    public void viewPublishers  (View v){
        Intent i = new Intent(HomePage.this, GamePublisherActivity.class );
        startActivity(i);
    }
    public void logoutPixl (View v){
        Intent i = new Intent(HomePage.this, LoginPage.class );
        startActivity(i);
    }
}
