package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GameActivity extends AppCompatActivity {
    ImageView gameImage;
    TextView textViewGameName;
    TextView textViewPrice;
    TextView textViewGameDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.games_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.games_view), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        gameImage = findViewById(R.id.game_image);
        textViewGameName = findViewById(R.id.game_name);
        textViewPrice = findViewById(R.id.game_price);
        textViewGameDesc = findViewById(R.id.game_description);

        Intent i = getIntent();

        gameImage.setImageResource(i.getIntExtra("image", 0));
        textViewGameName.setText(i.getStringExtra("name"));
        textViewPrice.setText(i.getStringExtra("price"));
        textViewGameDesc.setText(i.getStringExtra("description"));
    }
}
