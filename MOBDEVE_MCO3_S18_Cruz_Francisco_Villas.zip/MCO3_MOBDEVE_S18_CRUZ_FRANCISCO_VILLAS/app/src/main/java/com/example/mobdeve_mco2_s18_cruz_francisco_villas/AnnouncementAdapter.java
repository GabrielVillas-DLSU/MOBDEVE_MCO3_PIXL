package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AnnouncementAdapter extends RecyclerView.Adapter<AnnouncementAdapter.ViewHolder> {
    private AnnouncementData[] announcementData;
    private Context context;

    public AnnouncementAdapter(AnnouncementData[] announcementData, Context context) {
        this.announcementData = announcementData;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.announcement_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final AnnouncementData announcementDataList = announcementData[position];
        holder.textViewTitle.setText(announcementDataList.getAnnouncementTitle());
        holder.textViewDescription.setText(announcementDataList.getAnnouncementDesc());
        holder.textViewDate.setText(announcementDataList.getAnnouncementDate());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, announcementDataList.getAnnouncementTitle(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(context, AnnouncementActivity.class);
                i.putExtra("title",announcementDataList.getAnnouncementTitle());
                i.putExtra("date",announcementDataList.getAnnouncementDate());
                i.putExtra("description",announcementDataList.getAnnouncementDesc());

                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return announcementData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle;
        TextView textViewDescription;
        TextView textViewDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.announcement_title);
            textViewDescription = itemView.findViewById(R.id.announcement_description);
            textViewDate = itemView.findViewById(R.id.announcement_date);
        }
    }
}
