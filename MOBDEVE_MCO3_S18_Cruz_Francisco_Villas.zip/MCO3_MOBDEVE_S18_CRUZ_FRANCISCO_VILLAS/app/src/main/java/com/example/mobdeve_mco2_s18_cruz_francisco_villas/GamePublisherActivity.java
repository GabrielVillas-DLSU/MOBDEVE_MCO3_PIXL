package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class GamePublisherActivity extends AppCompatActivity {

    private RecyclerView announcementsRecyclerView, gamesRecyclerView;
    private Button followButton;
    private TextView followingIndicator;

    private static final String TAG = "GamePublisherActivity";
    private static final String PREFS_NAME = "FollowPrefs";
    private static final String KEY_FOLLOW_STATUS = "isFollowing";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.game_publisher);

        // UI setup
        followButton = findViewById(R.id.follow_button);
        followingIndicator = findViewById(R.id.following_indicator);
        setupRecyclerViews();

        // Load follow status from SharedPreferences
        loadFollowStatus();

        // Handle button clicks
        followButton.setOnClickListener(v -> {
            Log.d("FollowButton", "Follow button clicked");
            toggleFollowStatus();
        });
    }

    private void setupRecyclerViews() {
        announcementsRecyclerView = findViewById(R.id.announcements_recycler_view);
        gamesRecyclerView = findViewById(R.id.games_recycler_view);

        announcementsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        gamesRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        announcementsRecyclerView.setAdapter(new AnnouncementAdapter(loadAnnouncementData(), this));
        gamesRecyclerView.setAdapter(new GameAdapter(loadGameData(), this));
    }

    // Load the follow status from SharedPreferences
    private void loadFollowStatus() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isFollowing = sharedPreferences.getBoolean(KEY_FOLLOW_STATUS, false);
        setFollowingState(isFollowing);
    }

    // Toggle the follow status and save it to SharedPreferences
    private void toggleFollowStatus() {
        boolean isFollowing = followingIndicator.getVisibility() == View.VISIBLE;
        // Update the visibility of the following indicator and button text
        setFollowingState(!isFollowing);
        // Save the updated status to SharedPreferences
        saveFollowStatus(!isFollowing);
    }

    // Set the UI based on the follow status
    private void setFollowingState(boolean isFollowing) {
        followingIndicator.setVisibility(isFollowing ? View.VISIBLE : View.GONE);
        followButton.setText(isFollowing ? "Unfollow" : "Follow");
    }

    // Save the follow status to SharedPreferences
    private void saveFollowStatus(boolean isFollowing) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_FOLLOW_STATUS, isFollowing);
        editor.apply();
    }

    private AnnouncementData[] loadAnnouncementData() {
        return new AnnouncementData[]{
                new AnnouncementData("Publisher Sale", "Up to 50% off games!", "Sept. 1, 2024"),
                new AnnouncementData("Overcooked FAQ", "Available in multiple languages.", "August 28, 2024"),
                new AnnouncementData("Mario Party Update", "Bug fixes and improvements.", "July 9, 2024")
        };
    }

    private GameData[] loadGameData() {
        return new GameData[]{
                new GameData(R.drawable.crashbandicoot, "Crash Bandicoot", 2400, "Classic platformer."),
                new GameData(R.drawable.smashmelee, "Super Smash Bros.", 2900, "Crossover fighting game."),
                new GameData(R.drawable.locoroco, "LocoRoco", 995, "Unique puzzle-platformer.")
        };
    }
}
