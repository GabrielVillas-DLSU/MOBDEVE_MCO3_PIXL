package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LibraryGamesActivity extends AppCompatActivity {

    ImageView movieImage;
    TextView textViewName;
    TextView textViewDate;
    TextView textViewSummary;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.library_games_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        movieImage = findViewById(R.id.imageview);
        textViewName = findViewById(R.id.textName);
        textViewDate = findViewById(R.id.textdate);
        textViewSummary = findViewById(R.id.textsummary);

        Intent i = getIntent();

        movieImage.setImageResource(i.getIntExtra("image", 0));
        textViewName.setText(i.getStringExtra("name"));
        textViewDate.setText(i.getStringExtra("date"));
        textViewSummary.setText(i.getStringExtra("summary"));
    }
}