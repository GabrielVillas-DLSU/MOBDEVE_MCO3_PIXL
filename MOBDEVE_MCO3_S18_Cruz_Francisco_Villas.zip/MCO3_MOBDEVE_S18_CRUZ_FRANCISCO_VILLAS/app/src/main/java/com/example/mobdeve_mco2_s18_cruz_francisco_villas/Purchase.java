package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

public class Purchase {
    private String cardholderName;
    private String cardNumber;
    private String cardYear;
    private String cvv;
    private String billingFirstName;
    private String billingLastName;
    private String billingAddress;
    private String billingCity;
    private String billingState;
    private String billingPostalCode;
    private String billingCountry;
    private double totalAmount;

    // Constructor
    public Purchase(String cardholderName, String cardNumber, String cardYear, String cvv,
                    String billingFirstName, String billingLastName, String billingAddress,
                    String billingCity, String billingState, String billingPostalCode,
                    String billingCountry, double totalAmount) {
        this.cardholderName = cardholderName;
        this.cardNumber = cardNumber;
        this.cardYear = cardYear;
        this.cvv = cvv;
        this.billingFirstName = billingFirstName;
        this.billingLastName = billingLastName;
        this.billingAddress = billingAddress;
        this.billingCity = billingCity;
        this.billingState = billingState;
        this.billingPostalCode = billingPostalCode;
        this.billingCountry = billingCountry;
        this.totalAmount = totalAmount;
    }
}
