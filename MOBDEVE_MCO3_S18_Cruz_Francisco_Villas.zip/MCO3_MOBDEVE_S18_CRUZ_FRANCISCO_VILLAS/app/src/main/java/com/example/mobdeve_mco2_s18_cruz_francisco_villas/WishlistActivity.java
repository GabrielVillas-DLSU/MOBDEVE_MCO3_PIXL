package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.ListenerRegistration;

public class WishlistActivity extends AppCompatActivity {

    private RecyclerView recyclerWishlistView;
    private EditText searchBar;

    private List<Game> wishlistGames;
    private WishlistAdapter wishlistAdapter;

    private FirebaseFirestore db;
    private String userId;
    private ListenerRegistration wishlistListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        db = FirebaseFirestore.getInstance(); // Initialize Firestore
        userId = getCurrentUserId(); // Retrieve the user who is logged in

        recyclerWishlistView = findViewById(R.id.recycler_wishlist_view);
        searchBar = findViewById(R.id.search_bar);

        wishlistGames = new ArrayList<>();

        setupRecyclerView();
        setupSearchBar();

        loadWishlistFromFirebase(); // Load existing wishlist
    }

    private void loadWishlistFromFirebase() {
        DocumentReference wishlistRef = db.collection("wishlists").document(userId);

        wishlistListener = wishlistRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Toast.makeText(WishlistActivity.this, "Failed to load wishlist.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                List<Game> games = (List<Game>) documentSnapshot.get("games");
                if (games != null) {
                    wishlistGames.clear();
                    wishlistGames.addAll(games);
                    wishlistAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void saveWishlistToFirebase() {
        DocumentReference wishlistRef = db.collection("wishlists").document(userId);

        wishlistRef.set(new HashMap<String, Object>() {{
            put("games", wishlistGames);
        }}, SetOptions.merge()).addOnSuccessListener(aVoid -> {
        }).addOnFailureListener(e -> {
            Toast.makeText(WishlistActivity.this, "Failed to save wishlist.", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupRecyclerView() {
        wishlistAdapter = new WishlistAdapter(this, wishlistGames, new WishlistAdapter.OnRemoveClickListener() {
            @Override
            public void onRemoveClick(Game game) {
                wishlistGames.remove(game);
                saveWishlistToFirebase(); // Save once item is removed
                wishlistAdapter.notifyDataSetChanged();
                Toast.makeText(WishlistActivity.this, "Removed from wishlist", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerWishlistView.setAdapter(wishlistAdapter);
        recyclerWishlistView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupSearchBar() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterGames(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void filterGames(String text) {
        List<Game> filteredGames = new ArrayList<>();
        for (Game game : wishlistGames) {
            if (game.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredGames.add(game);
            }
        }
        wishlistAdapter.updateList(filteredGames);
    }

    public void addToCart(Game game) {
        Intent intent = new Intent(this, CartActivity.class);
        intent.putExtra("game_name", game.getName());
        intent.putExtra("game_price", game.getPrice());
        intent.putExtra("game_image", game.getImageResource());

        startActivity(intent);
    }

    private String getCurrentUserId() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            return user.getUid();
        } else {
            Intent loginIntent = new Intent(this, LoginPage.class); // Redirect to Login Activity if user is not logged in
            startActivity(loginIntent);
            finish();
            return null;
        }
    }
}