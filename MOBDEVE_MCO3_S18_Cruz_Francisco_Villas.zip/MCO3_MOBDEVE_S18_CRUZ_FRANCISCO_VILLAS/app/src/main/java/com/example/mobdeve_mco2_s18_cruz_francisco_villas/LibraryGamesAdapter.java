package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LibraryGamesAdapter extends RecyclerView.Adapter<LibraryGamesAdapter.ViewHolder> {

    LibraryGamesData[] libraryGamesData;
    Context context;

    public LibraryGamesAdapter(LibraryGamesData[] libraryGamesData, LibraryGamesMainActivity activity) {
        this.libraryGamesData = libraryGamesData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.library_games_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final LibraryGamesData libraryGamesDataList = libraryGamesData[position];
        holder.textViewName.setText(libraryGamesDataList.getMovieName());
        holder.textViewDate.setText(libraryGamesDataList.getMovieDate());
        holder.movieImage.setImageResource(libraryGamesDataList.getMovieImage());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, libraryGamesDataList.getMovieName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(context, DiscountedActivity.class);
                i.putExtra("image", libraryGamesDataList.getMovieImage());
                i.putExtra("name", libraryGamesDataList.getMovieName());
                i.putExtra("date", libraryGamesDataList.getMovieDate());
                i.putExtra("summary", libraryGamesDataList.getMovieSummary());

                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return libraryGamesData.length;
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView movieImage;
        TextView textViewName;
        TextView textViewDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            movieImage = itemView.findViewById(R.id.imageview);
            textViewName = itemView.findViewById(R.id.textName);
            textViewDate = itemView.findViewById(R.id.textdate);

        }
    }

}