package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

public class NotificationsData {

    private String notifTitle;
    private String notifDesc;
    private String notifDate;
    private String notifPublisher;

    public NotificationsData(String notifTitle, String notifPublisher, String notifDesc, String notifDate) {
        this.notifTitle = notifTitle;
        this.notifPublisher = notifPublisher;
        this.notifDesc = notifDesc;
        this.notifDate = notifDate;
    }

    public String getNotifTitle() {
        return notifTitle;
    }

    public void setNotifTitle(String notifTitle) {
        this.notifTitle = notifTitle;
    }

    public String getNotifDesc() {
        return notifDesc;
    }

    public void setNotifDesc(String notifDesc) {
        this.notifDesc = notifDesc;
    }

    public String getNotifDate() {
        return notifDate;
    }

    public void setNotifDate(String notifDate) {
        this.notifDate = notifDate;
    }

    public String getNotifPublisher() {
        return notifPublisher;
    }

    public void setNotifPublisher(String notifPublisher) {
        this.notifPublisher = notifPublisher;
    }
}
