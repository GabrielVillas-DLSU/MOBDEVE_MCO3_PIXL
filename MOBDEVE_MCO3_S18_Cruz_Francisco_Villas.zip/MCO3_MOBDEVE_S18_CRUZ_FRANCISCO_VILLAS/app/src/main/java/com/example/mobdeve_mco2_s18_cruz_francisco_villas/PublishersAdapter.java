package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PublishersAdapter extends RecyclerView.Adapter<PublishersAdapter.ViewHolder> {

    private List<String> publishers;
    private int placeholderImageResource;

    public PublishersAdapter(List<String> publishers, int placeholderImageResource) {
        this.publishers = publishers;
        this.placeholderImageResource = placeholderImageResource;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_publisher, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String publisherName = publishers.get(position);
        holder.publisherName.setText(publisherName);
        holder.publisherImage.setImageResource(placeholderImageResource);
    }

    @Override
    public int getItemCount() {
        return publishers.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView publisherImage;
        TextView publisherName;

        ViewHolder(View itemView) {
            super(itemView);
            publisherImage = itemView.findViewById(R.id.publisher_image);
            publisherName = itemView.findViewById(R.id.publisher_name);
        }
    }
}