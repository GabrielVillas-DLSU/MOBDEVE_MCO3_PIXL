package com.example.mobdeve_mco2_s18_cruz_francisco_villas;


import android.os.Bundle;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class FeaturedGames extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.featured_games);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FeaturedGamesData[] featuredGamesData = new FeaturedGamesData[]{
                new FeaturedGamesData("Persona 5 Royal", 3195, R.drawable.persona5, "Prepare for the award-winning RPG experience in this definitive edition of Persona 5 Royal, featuring a treasure trove of downloadable content included!"),
                new FeaturedGamesData("Resident Evil 4", 2195, R.drawable.residentevil4, "Survival is just the beginning. Six years have passed since the biological disaster in Raccoon City. Leon S. Kennedy, one of the survivors, tracks the president's kidnapped daughter to a secluded European village, where there is something terribly wrong with the locals."),
                new FeaturedGamesData("Stardew Valley", 3195, R.drawable.stardewvalley, "You've inherited your grandfather's old farm plot in Stardew Valley. Armed with hand-me-down tools and a few coins, you set out to begin your new life. Can you learn to live off the land and turn these overgrown fields into a thriving home?"),
                new FeaturedGamesData("GTA 5", 1195, R.drawable.gta5, "Grand Theft Auto V for PC offers players the option to explore the award-winning world of Los Santos and Blaine County in resolutions of up to 4k and beyond, as well as the chance to experience the game running at 60 frames per second"),
                new FeaturedGamesData("Tekken 8", 2279, R.drawable.tekken8, "Get ready for the next chapter in the legendary fighting game franchise, TEKKEN 8."),
                new FeaturedGamesData("Resident Evil Village", 2311, R.drawable.re8, "Experience survival horror like never before in the 8th major installment in the Resident Evil franchise - Resident Evil Village. With detailed graphics, intense first-person action and masterful storytelling, the terror has never felt more realistic."),
                new FeaturedGamesData("Splatoon 3", 1992, R.drawable.splatoon3, "Enter 4-on-4* ink-slinging battles in this colorful action shooter packed with style and attitude. As a squid-like Inkling, quickly cover your surroundings (and opponents) in ink with wild weaponry and swim through your own color to sneak and splat. Dive into the fresh fun with family and friends and make waves as a team. Get splatted by an opponent? No sweat! The goal in Turf War is to cover the most ground, so respawn and jump back into the inky action."),
        };

        FeaturedGamesAdapter featuredGamesAdapter = new FeaturedGamesAdapter(featuredGamesData,FeaturedGames.this);
        recyclerView.setAdapter(featuredGamesAdapter);
    }
}


