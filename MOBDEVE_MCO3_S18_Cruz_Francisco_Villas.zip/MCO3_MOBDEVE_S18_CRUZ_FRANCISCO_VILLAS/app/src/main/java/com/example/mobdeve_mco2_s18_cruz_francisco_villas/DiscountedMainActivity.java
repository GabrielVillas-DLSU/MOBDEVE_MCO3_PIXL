package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DiscountedMainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.discounted_activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DiscountedData[] discountedData = new DiscountedData[]{
                new DiscountedData("Tomb Raider Remastered","455 Pesos",R.drawable.tombraiderremastered,"Play the original three Tomb Raider adventures with all expansions and secret levels in this definitive collection."),
                new DiscountedData("Assassins Creed Mirage","1,049 Pesos",R.drawable.assasinscreed_mirage,  "Experience the story of Basim, a cunning street thief with nightmarish visions, seeking answers and justice as he navigates the bustling streets of ninth-century Baghdad."),
                new DiscountedData("Chef RPG","315 pesos",R.drawable.chef_rpg, "Craft your culinary adventure in a beautiful pixel art world. Manage your restaurants, forage and hunt for ingredients, befriend locals, and grow your culinary empire. What kind of chef will you be?"),
                new DiscountedData("Little Nightmares","200 pesos",R.drawable.little_nightmares, "Take on the role of Six, a lone child lost in a massive metal vessel known as the Maw, surrounded by dangerous, distorted versions of adults. You’ll need to do your best to escape in one piece or your fate will be worse than you ever dared dream."),
                new DiscountedData("Dwarf Fortress","728 Pesos",R.drawable.dwarf, "The deepest, most intricate simulation of a world that's ever been created. The legendary Dwarf Fortress is now on Steam. Build a fortress and try to help your dwarves survive against a deeply generated world."),
                new DiscountedData("2K25","2,044 Pesos",R.drawable.twoktwenty5, "Command every court with authenticity and realism Powered by ProPLAY™, giving you ultimate control over how you play in NBA 2K25. Define your legacy in MyCAREER, MyTEAM, MyNBA, and The W."),
                new DiscountedData("Pacify","50 pesos",R.drawable.pacify, "There is reportedly an evil inside that house. Something about an old funeral parlor offering a last chance to talk to their dead loved ones. Plus something about lights, laughter, a girl, missing people, etc... You know the same stuff everyone claims. Take a team, and check the place out."),
        };

        DiscountedAdapter discountedAdapter = new DiscountedAdapter(discountedData,DiscountedMainActivity.this);
        recyclerView.setAdapter(discountedAdapter);
    }
}