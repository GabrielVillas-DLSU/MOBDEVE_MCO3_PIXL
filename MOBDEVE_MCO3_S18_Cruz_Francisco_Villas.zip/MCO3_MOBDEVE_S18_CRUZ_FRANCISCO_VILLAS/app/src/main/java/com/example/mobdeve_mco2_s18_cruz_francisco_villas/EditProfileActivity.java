package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;

public class EditProfileActivity extends AppCompatActivity {

    private EditText editFullName, editUsername, editDescription;
    private ImageView profileImageView; // prof pic
    private Button saveButton;

    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_edit_profile);

        db = FirebaseFirestore.getInstance();
        userId = getIntent().getStringExtra("USER_ID"); // Pass user ID from ProfileActivity
/*
        editFullName = findViewById(R.id.edit_full_name);
        editUsername = findViewById(R.id.edit_username);
        editDescription = findViewById(R.id.edit_description);
        profileImageView = findViewById(R.id.profile_image); // prof pic
        saveButton = findViewById(R.id.save_button);
*/
        loadUserInfo();

        saveButton.setOnClickListener(v -> saveProfile());
    }

    private void loadUserInfo() {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        editFullName.setText(documentSnapshot.getString("fullName"));
                        editUsername.setText(documentSnapshot.getString("username"));
                        editDescription.setText(documentSnapshot.getString("description"));
                        // profile image; can't make Glide work :(
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(EditProfileActivity.this, "Failed to load user info.", Toast.LENGTH_SHORT).show());
    }

    private void saveProfile() {
        String fullName = editFullName.getText().toString();
        String username = editUsername.getText().toString();
        String description = editDescription.getText().toString();

        db.collection("users").document(userId).update(
                "fullName", fullName,
                "username", username,
                "description", description
        ).addOnSuccessListener(aVoid -> {
            Toast.makeText(EditProfileActivity.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
            finish(); // Return to ProfileActivity
        }).addOnFailureListener(e -> Toast.makeText(EditProfileActivity.this, "Failed to update profile", Toast.LENGTH_SHORT).show());
    }
}