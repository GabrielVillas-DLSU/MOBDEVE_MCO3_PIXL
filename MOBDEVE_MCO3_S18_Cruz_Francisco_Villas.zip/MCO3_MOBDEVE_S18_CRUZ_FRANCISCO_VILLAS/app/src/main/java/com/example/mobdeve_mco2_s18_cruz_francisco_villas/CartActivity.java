package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.ListenerRegistration;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerCartView;
    private TextView totalAmountTextView;
    private Button proceedToPurchaseButton;

    private FirebaseFirestore db;
    private String userId;
    private ListenerRegistration cartListener;

    private ArrayList<Game> cartGames;
    private CartAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        db = FirebaseFirestore.getInstance(); // Initialize Firestore

        recyclerCartView = findViewById(R.id.recycler_cart_view);
        totalAmountTextView = findViewById(R.id.total_amount);
        proceedToPurchaseButton = findViewById(R.id.proceed_to_purchase_button);

        userId = getCurrentUserId(); // Retrieve the user who is logged in
        cartGames = new ArrayList<>();

        // pa-check if this is korique :'-)
        if (getIntent().hasExtra("selected_game")) {
            Game selectedGame = (Game) getIntent().getSerializableExtra("selected_game");
            if (selectedGame != null) {
                addGameToCart(selectedGame);
            }
        }

        setupRecyclerView();
        loadCartFromFirebase(); // Load existing cart

        proceedToPurchaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CartActivity.this, PurchasePage.class); // Goes to Purchase Activity
                startActivity(i);
                Toast.makeText(CartActivity.this, "Proceeding to purchase...", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadCartFromFirebase() {
        DocumentReference cartRef = db.collection("carts").document(userId);

        cartListener = cartRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Toast.makeText(CartActivity.this, "Failed to load cart.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                List<Game> games = (List<Game>) documentSnapshot.get("games");
                if (games != null) {
                    cartGames.clear();
                    cartGames.addAll(games);
                    cartAdapter.notifyDataSetChanged();
                    updateTotalAmount();
                }
            }
        });
    }

    private void saveCartToFirebase() {
        DocumentReference cartRef = db.collection("carts").document(userId);

        cartRef.set(new HashMap<String, Object>() {{
            put("games", cartGames);
        }}, SetOptions.merge()).addOnSuccessListener(aVoid -> {
        }).addOnFailureListener(e -> {
            Toast.makeText(CartActivity.this, "Failed to save cart.", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupRecyclerView() {
        cartAdapter = new CartAdapter(cartGames, game -> {
            cartGames.remove(game);
            saveCartToFirebase();
            updateTotalAmount();
            Toast.makeText(CartActivity.this, "Removed from cart successfully", Toast.LENGTH_SHORT).show();
        });

        recyclerCartView.setAdapter(cartAdapter);
        recyclerCartView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void updateTotalAmount() {
        double totalAmount = 0;
        for (Game game : cartGames) {
            totalAmount += game.getPrice();
        }
        totalAmountTextView.setText(String.format("Total Amount: ₱%.2f", totalAmount));
    }

    public void addGameToCart(Game game) {
        if (!cartGames.contains(game)) {
            cartGames.add(game);
            saveCartToFirebase();
            updateTotalAmount();
            Toast.makeText(this, game.getName() + " added to cart.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, game.getName() + " is already in the cart.", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentUserId() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            return user.getUid();
        } else {
            Intent loginIntent = new Intent(this, LoginPage.class); // Redirect to Login Activity if user is not logged in
            startActivity(loginIntent);
            finish();
            return null;
        }
    }
}