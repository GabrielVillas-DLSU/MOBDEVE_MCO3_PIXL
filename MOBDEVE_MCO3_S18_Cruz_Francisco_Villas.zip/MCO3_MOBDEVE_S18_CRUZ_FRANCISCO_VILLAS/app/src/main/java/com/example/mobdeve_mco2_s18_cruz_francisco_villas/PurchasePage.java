package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class PurchasePage extends AppCompatActivity {

    private TextView purchaseTotalTextView;  // Assuming this is where you want to display the price

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase_page);  // Use the XML layout

        purchaseTotalTextView = findViewById(R.id.purchase_total);

        double totalAmount = getIntent().getDoubleExtra ("totalAmount", 0);

        purchaseTotalTextView.setText(String.format("Total: P%.2f", totalAmount));

        EditText cardholderName = findViewById(R.id.cardholder_name);
        EditText cardNumber = findViewById(R.id.card_number);
        EditText cardYear = findViewById(R.id.card_year);
        EditText cvv = findViewById(R.id.cvv);
        EditText billingFirstName = findViewById(R.id.billing_firstname);
        EditText billingLastName = findViewById(R.id.billing_lastname);
        EditText billingAddress = findViewById(R.id.billing_address);
        EditText billingCity = findViewById(R.id.billing_city);
        EditText billingState = findViewById(R.id.billing_state);
        EditText billingPostalCode = findViewById(R.id.billing_postal_code);
        EditText billingCountry = findViewById(R.id.billing_country);

        Button purchaseButton = findViewById(R.id.purchase_button);
        Button cancelButton = findViewById(R.id.cancel_button);
        purchaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(cardholderName.getText().toString()) ||
                        TextUtils.isEmpty(cardNumber.getText().toString()) ||
                        TextUtils.isEmpty(cardYear.getText().toString()) ||
                        TextUtils.isEmpty(cvv.getText().toString()) ||
                        TextUtils.isEmpty(billingFirstName.getText().toString()) ||
                        TextUtils.isEmpty(billingLastName.getText().toString()) ||
                        TextUtils.isEmpty(billingAddress.getText().toString()) ||
                        TextUtils.isEmpty(billingCity.getText().toString()) ||
                        TextUtils.isEmpty(billingState.getText().toString()) ||
                        TextUtils.isEmpty(billingPostalCode.getText().toString()) ||
                        TextUtils.isEmpty(billingCountry.getText().toString())) {
                    Toast.makeText(PurchasePage.this, "Please fill in all fields before purchasing.", Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Purchases");
                    String purchaseId = databaseReference.push().getKey();
                    Purchase purchase = new Purchase(
                            cardholderName.getText().toString(),
                            cardNumber.getText().toString(),
                            cardYear.getText().toString(),
                            cvv.getText().toString(),
                            billingFirstName.getText().toString(),
                            billingLastName.getText().toString(),
                            billingAddress.getText().toString(),
                            billingCity.getText().toString(),
                            billingState.getText().toString(),
                            billingPostalCode.getText().toString(),
                            billingCountry.getText().toString(),
                            totalAmount
                    );

                    if (purchaseId != null) {
                        databaseReference.child(purchaseId).setValue(purchase).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(PurchasePage.this, "Purchase successful! Thank you for purchasing!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(PurchasePage.this, HomePage.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(PurchasePage.this, "Failed to save purchase. Try again.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
