package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DiscountedAdapter extends RecyclerView.Adapter<DiscountedAdapter.ViewHolder> {

    DiscountedData[] discountedData;
    Context context;

    public DiscountedAdapter(DiscountedData[] discountedData, DiscountedMainActivity activity) {
        this.discountedData = discountedData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.discounted_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final DiscountedData discountedDataList = discountedData[position];
        holder.textViewName.setText(discountedDataList.getMovieName());
        holder.textViewDate.setText(discountedDataList.getMovieDate());
        holder.movieImage.setImageResource(discountedDataList.getMovieImage());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, discountedDataList.getMovieName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(context, DiscountedActivity.class);
                i.putExtra("image", discountedDataList.getMovieImage());
                i.putExtra("name", discountedDataList.getMovieName());
                i.putExtra("date", discountedDataList.getMovieDate());
                i.putExtra("summary", discountedDataList.getMovieSummary());

                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return discountedData.length;
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView movieImage;
        TextView textViewName;
        TextView textViewDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            movieImage = itemView.findViewById(R.id.imageview);
            textViewName = itemView.findViewById(R.id.textName);
            textViewDate = itemView.findViewById(R.id.textdate);

        }
    }

}

