package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Announcement_MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.game_publisher);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.gamepub), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.announcements_recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        AnnouncementData[] announcementData = new AnnouncementData[]{
                new AnnouncementData("Publisher Sale", "Get up to 50% off on selected games. Sale ends on Sept. 15, 2024.", "Sept. 1, 2024"),
                new AnnouncementData("Overcooked FAQ - Available Languages", "The game is available in: English, French, Italian, German, Spanish, Chinese, Japanese, Korean, Brazilian, Portuguese, Polish", "August 28, 2024"),
                new AnnouncementData("Mario Party Update Ver. 1.1.1", "General Updates: Fixed an issue in which the minigame does not end when playing Ice-Rink Risk, Dizzy Dancing, Catch You Letter, or Cheep Cheep Chase.\nFixed an issue in the Stick and Spin minigame in which the game’s movement gets slower as the high score gets raised and the game forcibly ends.\nFixed other issues to improve the overall gameplay experience.", "July 9, 2024")
        };

        AnnouncementAdapter announcementAdapter = new AnnouncementAdapter(announcementData, Announcement_MainActivity.this);
        recyclerView.setAdapter(announcementAdapter);
    }
}
