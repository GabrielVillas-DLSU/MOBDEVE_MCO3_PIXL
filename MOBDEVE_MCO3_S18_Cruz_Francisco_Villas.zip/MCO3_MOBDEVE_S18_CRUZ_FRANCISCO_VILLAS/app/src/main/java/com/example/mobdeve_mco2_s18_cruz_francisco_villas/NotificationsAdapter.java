package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder> {

    NotificationsData[] notifsData;
    Context context;

    // Constructor
    public NotificationsAdapter(NotificationsData[] notifsData, Context context) {
        this.notifsData = notifsData;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.notification_view,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final NotificationsData notifsDataList = notifsData[position];
        holder.textViewTitle.setText(notifsDataList.getNotifTitle());
        holder.textViewPublisher.setText(notifsDataList.getNotifPublisher());
        holder.textViewDate.setText(notifsDataList.getNotifDate());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, notifsDataList.getNotifTitle(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(context, NotificationsActivity.class);
                i.putExtra("title",notifsDataList.getNotifTitle());
                i.putExtra("publisher name",notifsDataList.getNotifPublisher());
                i.putExtra("description",notifsDataList.getNotifDesc());
                i.putExtra("date",notifsDataList.getNotifDate());

                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount(){
        return notifsData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle;
        TextView textViewPublisher;
        TextView textViewDate;
        TextView textViewDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.notification_title);
            textViewPublisher = itemView.findViewById(R.id.publisher_name);
            textViewDesc = itemView.findViewById(R.id.notification_desc);
            textViewDate = itemView.findViewById(R.id.notification_date);
        }
    }
}
