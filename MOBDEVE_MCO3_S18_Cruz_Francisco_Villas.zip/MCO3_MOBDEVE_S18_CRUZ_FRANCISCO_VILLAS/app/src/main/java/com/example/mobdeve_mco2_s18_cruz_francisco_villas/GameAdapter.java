package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.ViewHolder> {
    private GameData[] gameData;
    private Context context;


    public GameAdapter(GameData[] gameData, Context context) {
        this.gameData = gameData;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.games_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final GameData gameDataItem = gameData[position];
        holder.textViewGameName.setText(gameDataItem.getGameTitle());
        holder.gameImage.setImageResource(gameDataItem.getGameImage());
        holder.textViewPrice.setText(String.valueOf(gameDataItem.getGamePrice()));
        holder.textViewGameDesc.setText(gameDataItem.getGameDesc());

        holder.itemView.setOnClickListener(v -> {
            Toast.makeText(context, gameDataItem.getGameTitle(), Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(context, GameActivity.class);
            intent.putExtra("image", gameDataItem.getGameImage());
            intent.putExtra("name", gameDataItem.getGameTitle());
            intent.putExtra("price", gameDataItem.getGamePrice());
            intent.putExtra("description", gameDataItem.getGameDesc());

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return gameData.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView gameImage;
        TextView textViewGameName;
        TextView textViewPrice;
        TextView textViewGameDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            gameImage = itemView.findViewById(R.id.game_image);
            textViewGameName = itemView.findViewById(R.id.game_name);
            textViewPrice = itemView.findViewById(R.id.game_price);
            textViewGameDesc = itemView.findViewById(R.id.game_description);
        }
    }
}
