package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {

    private RecyclerView recyclerPublishersView;
    private RecyclerView recyclerGamesView;
    private TextView userNameTextView, userHandleTextView, userDescriptionTextView;
    private ImageView profileImageView;
    private Button editProfileButton;

    private FirebaseFirestore db;
    private String userId;
    private ListenerRegistration userListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        db = FirebaseFirestore.getInstance();
        userId = getCurrentUserId();

        recyclerPublishersView = findViewById(R.id.recycler_publishers_view);
        recyclerGamesView = findViewById(R.id.recycler_games_view);
        userNameTextView = findViewById(R.id.user_name);
        userHandleTextView = findViewById(R.id.user_handle);
        userDescriptionTextView = findViewById(R.id.user_description);
        profileImageView = findViewById(R.id.profile_image);
        editProfileButton = findViewById(R.id.edit_profile_button);

        setupRecyclerViews();
        loadUserInfo();

        editProfileButton.setOnClickListener(v -> editProfile());
    }

    private String getCurrentUserId() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            return user.getUid();
        } else {
            Intent loginIntent = new Intent(this, LoginPage.class); // Redirect to Login Activity if user is not logged in
            startActivity(loginIntent);
            finish();
            return null;
        }
    }

    private void setupRecyclerViews() {
        recyclerGamesView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerGamesView.setAdapter(new GamesAdapter(new ArrayList<>(), R.drawable.ic_game)); // Placeholder for games
    }

    private void loadUserInfo() {
        DocumentReference userRef = db.collection("users").document(userId);

        userListener = userRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Toast.makeText(ProfileActivity.this, "Failed to load user info.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                String fullName = documentSnapshot.getString("fullName");
                String username = documentSnapshot.getString("username");
                String description = documentSnapshot.getString("description");
                String profileImageUrl = documentSnapshot.getString("profileImageUrl");

                userNameTextView.setText(fullName);
                userHandleTextView.setText(username);
                userDescriptionTextView.setText(description);

                // Load profile image.. but idk how to make this work huhu
                /*
                if (profileImageUrl != null) {
                    Glide.with(this)
                            .load(profileImageUrl)
                            .placeholder(R.drawable.ic_pfp) // Placeholder image resource
                            .into(profileImageView);
                }
                */

                loadFollowedPublishers();
                loadFavoriteGames();
            }
        });
    }

    private void loadFollowedPublishers() {
        ArrayList<String> publishersList = new ArrayList<>();

        db.collection("users").document(userId).collection("followedPublishers").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        task.getResult().forEach(document -> publishersList.add(document.getString("publisherName")));
                        PublishersAdapter publishersAdapter = new PublishersAdapter(publishersList, R.drawable.ic_pfp);
                        recyclerPublishersView.setAdapter(publishersAdapter);
                        recyclerPublishersView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
                    }
                });
    }

    private void loadFavoriteGames() {
        ArrayList<String> gamesList = new ArrayList<>();

        db.collection("users").document(userId).collection("favoriteGames").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        task.getResult().forEach(document -> gamesList.add(document.getString("gameName")));
                        GamesAdapter gamesAdapter = new GamesAdapter(gamesList, R.drawable.ic_game);
                        recyclerGamesView.setAdapter(gamesAdapter);
                        recyclerGamesView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
                    }
                });
    }

    private void editProfile() {
        Intent intent = new Intent(this, EditProfileActivity.class);
        intent.putExtra("USER_ID", userId); // Pass user ID to EditProfileActivity
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (userListener != null) {
            userListener.remove();
        }
    }
}