package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

public class GameData {

    private Integer gameImage;
    private String gameTitle;
    private Integer gamePrice;
    private String gameDesc;

    public GameData(Integer gameImage, String gameTitle, Integer gamePrice, String gameDesc){
        this.gameImage = gameImage;
        this.gameTitle = gameTitle;
        this.gamePrice = gamePrice;
        this.gameDesc = gameDesc;
    }

    public Integer getGameImage(){
        return gameImage;
    }

    public void setGameImage(Integer gameImage){
        this.gameImage = gameImage;
    }

    public String getGameTitle(){
        return gameTitle;
    }

    public void setGameTitle(String gameTitle){
        this.gameTitle = gameTitle;
    }

    public Integer getGamePrice(){
        return gamePrice;
    }

    public void setGamePrice(Integer gamePrice) {
        this.gamePrice = gamePrice;
    }

    public String getGameDesc(){
        return gameDesc;
    }

    public void setGameDesc(String gameDesc){
        this.gameDesc = gameDesc;
    }
}
