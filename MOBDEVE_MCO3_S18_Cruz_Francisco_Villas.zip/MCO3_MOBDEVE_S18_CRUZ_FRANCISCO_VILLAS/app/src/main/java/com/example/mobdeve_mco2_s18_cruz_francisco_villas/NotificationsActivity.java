package com.example.mobdeve_mco2_s18_cruz_francisco_villas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class NotificationsActivity extends AppCompatActivity {
    TextView textViewTitle;
    TextView textViewPublisher;
    TextView textViewDesc;
    TextView textViewDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.notification_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.notif_main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewTitle = findViewById(R.id.notification_title);
        textViewPublisher = findViewById(R.id.publisher_name);
        textViewDesc = findViewById(R.id.notification_desc);
        textViewDate = findViewById(R.id.notification_date);

        Intent i = getIntent();

        textViewTitle.setText(i.getStringExtra("title"));
        textViewPublisher.setText(i.getStringExtra("publisher name"));
        textViewDesc.setText(i.getStringExtra("description"));
        textViewDate.setText(i.getStringExtra("date"));
    }
}
